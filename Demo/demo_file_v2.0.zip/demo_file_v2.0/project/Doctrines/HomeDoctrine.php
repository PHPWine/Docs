<?php namespace PHPWineShowcase\Doctrines; ?>
<?php 
  
  use \PHPWineOptimizedHtml\doctrine\Doctrine;
 
 Class HomeDoctrine  {
   
   protected $wine;
   protected $obj;
   public function __construct()
   {
     $this->wine = new \PHPWineOptimizedHtml\OptimizedHtml;      
   }

   /* Doctrine or template for list li or ol tag */
   public function ul_child(
     array $attributes = [],
     array $section_page = [], 
     array $hook_top_later = [],
     array $hook_bottom_later = []
   ) {

    $wine = new Doctrine([
      attributes   => $attributes,
      hooks        => $section_page,
      top_later    => $hook_top_later,
      bottom_later => $hook_bottom_later,
    ]); 
    
    $layout = $wine->visible()
    ->screen()
    ->layout();

    return $layout;
    
   }
 
}
