<?php namespace PHPWineShowcase\Components; ?>
<?php 

 use \PHPWineShowcase\Apps\HeaderApp;

 Class MenuList extends HeaderApp {
 
    public function component_top_menu($links) {

      /* Doctrine of parent for li ol tags */  
      return $this->ul_child(
        [ id => "menu_link"],
        [
          xrow => [
            [$this,'hero_section',[$links]]
          ]
        ],
        ['ttlater_hero'],
        ['btlater_hero',[333]]        
       );

    }

   public function hero_section($links) {

      return wine(ul, [
       
        child => [
  
          please => function() use ($links) {
  
            $__link = []; foreach($links as $link) { 
       
               $__link[] = wine(li, $link);  
               
            }
             
           return $__link;
         }
       ] 
  
     ]);

   }



  }  
    