<?php namespace PHPWineShowcase\Components; ?>
<?php 

use \PHPWineShowcase\Apps\HeaderApp;

Class Branding extends HeaderApp {

  public function component_top_branding($branding) {

    return $this->wine->wine(__, 
     $this->wine->wine(h5,$branding)
   );

  }

 }  
    