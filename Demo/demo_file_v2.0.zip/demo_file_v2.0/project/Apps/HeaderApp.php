<?php namespace PHPWineShowcase\Apps; ?>
<?php 

use \PHPWineShowcase\Doctrines\HomeDoctrine;
use \PHPWineShowcase\Components\Branding;
use \PHPWineShowcase\Components\MenuList;

class HeaderApp extends HomeDoctrine {

 protected $branding;
 protected $menu_items;
 protected $app;

 public function branding(mixed $branding = '') {
  
   $this->branding = $branding;
   return $this;

 }

 public function menu(array $menu_items = []) {
    
  $this->menu_items = $menu_items;
  return $this;
 
 }

 public function app() {

  return wine('section', [ 
   child => [
    [div, value=>[value(Branding::class,'component_top_branding',$this->branding)]],
    [div, value=>[value(MenuList::class,'component_top_menu',$this->menu_items)]]
   ]
  ]);

 }

}  
