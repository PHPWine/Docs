<?php require dirname(__FILE__) . DIRECTORY_SEPARATOR .'./vendor/autoload.php'; ?>
<?php 

// Main header
$app_header = new \PHPWineShowcase\Apps\HeaderApp;

print $app_header->branding('BrandLogo')->menu([
    
  'Home',
  'About',
  'Services',
  'Contact Us'

])->app();

function bottom_btlater_hero($hh) {
  
   $from_somewhere = 413;
   
   $obj = new class {

    public function func_div($from_somewhere, $hh) {
      return "Hello world by bany ".$from_somewhere . $hh;
    }
  
   };

   $drop = new \PHPWineOptimizedHtml\doctrine\Doctrine([
     hooks => [
       columns => [
         [$obj,'func_div', [$from_somewhere, $hh]]
       ]
     ]
   ]);

  return $drop->visible()
  ->screen()
  ->layout(); 

}



