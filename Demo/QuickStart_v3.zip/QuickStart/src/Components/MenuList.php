<?php namespace PHPAutoloader\Classes\Components; ?>
<?php 

 use \PHPAutoloader\Classes\Apps\HeaderApp;

 Class MenuList extends HeaderApp {

    public function component_top_right_menu($links) {

      /* Doctrine of parent for li ol tags */  
      return $this->ul_parent($links, $this);  

    } 

    public function ul_child_lists($links) {
       
        return $this->wine->wine(__, [
           child => [
             please => function() use ($links) {

               $__link = []; foreach($links as $link) { 
          
                  $__link[] = $this->wine->wine('li', $link);  
                  
                }
                
              return $__link;
            }
          ] 
        ]);
       
    }

  }  
    