<?php namespace PHPAutoloader\Classes\Apps; ?>
<?php 

use \PHPAutoloader\Classes\Doctrines\HomeDoctrine;
use \PHPAutoloader\Classes\Components\Branding;
use \PHPAutoloader\Classes\Components\MenuList;

Class HeaderApp extends HomeDoctrine {

  protected array $links = [
    'Home',
    'About',
    'Services',
    'Contact Us'
  ];

 public function MainHeader() {

   return $this->wine->wine('section', [

    $this->wine::child => [
      ['div', $this->wine::value=>[ $this->wine->value((new Branding),'component_top_logo_header')]],
      ['div', $this->wine::value=>[ $this->wine->value(MenuList::class,'component_top_right_menu', $this->links ) ]]
    ]
   ]);

 }


}  
