<?php 

 require dirname(__FILE__) . DIRECTORY_SEPARATOR .'./PHPAutoloader.php';
 require dirname(__FILE__) . DIRECTORY_SEPARATOR .'./vendor/autoload.php';

  $new = new \PHPAutoloader\Classes\Apps\HeaderApp;

  print $new->MainHeader();