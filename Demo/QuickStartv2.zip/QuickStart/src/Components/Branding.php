<?php namespace PHPAutoloader\Classes\Components; ?>
<?php 

use \PHPAutoloader\Classes\Apps\HeaderApp;

Class Branding extends HeaderApp {

  public function component_top_logo_header() {

    return $this->wine->wine(__, 
     $this->wine->wine('h5','BRANDLOGO')
   );

  }

 }  
    