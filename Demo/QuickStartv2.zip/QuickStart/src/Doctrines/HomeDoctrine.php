<?php namespace PHPAutoloader\Classes\Doctrines; ?>
<?php 

 Class HomeDoctrine  {
   
   protected $wine;
   protected $obj;
   public function __construct()
   {
     $this->wine = new \PHPWineOptimizedHtml\OptimizedHtml;      
   }

   /* Doctrine or template for list li or ol tag */
   public function ul_parent($args,$bj=null,$method_ul=null) : string {

     return $this->wine->wine(__,[
       child => [
         ['ul', value=>[$this->wine->magic(
           $bj??$this, 
           $method_ul, 
           $this->wine->value($bj??$this,'ul_child_lists',$args) 
         )]] 
       ]
     ]); 

   }
 
}
